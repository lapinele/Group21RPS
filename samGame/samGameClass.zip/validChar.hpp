/*********************************************************************
** Program name: validInput.hpp
** Author: 
** Date: 
** Description: 
*********************************************************************/

#ifndef VALIDCHAR_HPP
#define VALIDCHAR_HPP

#include <iostream>
using std::cout;
using std::cin;
using std::endl;

#include <string>
using std::string;

char validChar(string strIn, char arrIn[], int arrSize);

#endif
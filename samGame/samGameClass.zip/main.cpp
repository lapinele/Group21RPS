/*********************************************************************
 * Program name: Rock, Paper, Scissors
 * Author: Noah Buchen, Alexandra Henley, Elliott Lapinel, Patrick
 * Rice, and Samantha Tone
 * Date: 10/25/2017
 * Description:
*********************************************************************/

#include "RPSGame.hpp"

int main() {
    
	RPSGame rps;
	rps.playGame();

    return 0;
}
